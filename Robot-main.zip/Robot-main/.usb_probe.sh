#!/data/data/com.termux/files/usr/bin/bash
exec python3 /data/data/com.termux/files/home/updated/usb_transport.py --probe "$@"
